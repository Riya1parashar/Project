/*
SQLyog Community v13.1.7 (64 bit)
MySQL - 8.0.28 : Database - e-health-care-management-system
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`e-health-care-management-system` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `e-health-care-management-system`;

/*Table structure for table `admitpatient` */

DROP TABLE IF EXISTS `admitpatient`;

CREATE TABLE `admitpatient` (
  `Id` bigint NOT NULL,
  `patientId` bigint DEFAULT NULL,
  `PatientName` varchar(225) DEFAULT NULL,
  `doctorName` varchar(225) DEFAULT NULL,
  `wardName` varchar(225) DEFAULT NULL,
  `roomNo` varchar(225) DEFAULT NULL,
  `bedId` bigint DEFAULT NULL,
  `bedNo` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `disease` varchar(1500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `admitDate` date DEFAULT NULL,
  `status` varchar(225) DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Pk_patient_id` (`patientId`),
  CONSTRAINT `Pk_patient_id` FOREIGN KEY (`patientId`) REFERENCES `patient` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `admitpatient` */

insert  into `admitpatient`(`Id`,`patientId`,`PatientName`,`doctorName`,`wardName`,`roomNo`,`bedId`,`bedNo`,`disease`,`admitDate`,`status`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,1,'Rajah Franks','DOca','adf','101',0,'1','sdv','2021-10-10','Admited','Hyteci123','Hyteci123','2021-11-13 13:07:12','2021-11-13 13:07:12'),
(2,1,'Rajah Franks','fbdfbdfb','101','102',0,'102','adsvcsdvsdv','2022-03-15','Admited','Hyteci123','Hyteci123','2022-03-14 08:17:08','2022-03-14 08:17:19');

/*Table structure for table `appointment` */

DROP TABLE IF EXISTS `appointment`;

CREATE TABLE `appointment` (
  `Id` bigint NOT NULL,
  `patientId` bigint DEFAULT NULL,
  `patientName` varchar(225) DEFAULT NULL,
  `doctorId` bigint DEFAULT NULL,
  `DoctorName` varchar(225) DEFAULT NULL,
  `ScheduleId` bigint DEFAULT NULL,
  `date` date DEFAULT NULL,
  `allergy` varchar(1500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Fk_patient` (`patientId`),
  CONSTRAINT `Fk_patient` FOREIGN KEY (`patientId`) REFERENCES `patient` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `appointment` */

insert  into `appointment`(`Id`,`patientId`,`patientName`,`doctorId`,`DoctorName`,`ScheduleId`,`date`,`allergy`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,1,'Rajah Franks',1,'Cleo Maldonado',1,'2021-11-12','xvvbdfbdf','sipuniq','sipuniq','2021-11-13 11:11:06','2021-11-13 11:11:06');

/*Table structure for table `bed` */

DROP TABLE IF EXISTS `bed`;

CREATE TABLE `bed` (
  `Id` bigint NOT NULL,
  `roomId` bigint DEFAULT NULL,
  `roomNo` varchar(225) DEFAULT NULL,
  `BedNo` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `description` varchar(225) DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Fk_Room_ID` (`roomId`),
  CONSTRAINT `Fk_Room_ID` FOREIGN KEY (`roomId`) REFERENCES `room` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `bed` */

insert  into `bed`(`Id`,`roomId`,`roomNo`,`BedNo`,`description`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,1,'101','01','gvnhmn','Admin123','Admin123','2021-11-12 13:28:30','2021-11-12 13:28:30');

/*Table structure for table `bill` */

DROP TABLE IF EXISTS `bill`;

CREATE TABLE `bill` (
  `Id` bigint NOT NULL,
  `patientId` bigint DEFAULT NULL,
  `PatientName` varchar(225) DEFAULT NULL,
  `Amount` varchar(225) DEFAULT NULL,
  `Status` varchar(225) DEFAULT NULL,
  `Description` varchar(225) DEFAULT NULL,
  `Created_By` varchar(225) DEFAULT NULL,
  `Modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_Datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `bill` */

insert  into `bill`(`Id`,`patientId`,`PatientName`,`Amount`,`Status`,`Description`,`Created_By`,`Modified_by`,`created_datetime`,`modified_Datetime`) values 
(1,1,'Rajah Franks','2000','Paid','cv vc','Hyteci123','Hyteci123','2021-11-13 16:04:18','2021-11-13 16:04:18');

/*Table structure for table `doctor` */

DROP TABLE IF EXISTS `doctor`;

CREATE TABLE `doctor` (
  `id` bigint NOT NULL,
  `firstName` varchar(225) DEFAULT NULL,
  `lastName` varchar(225) DEFAULT NULL,
  `userName` varchar(225) DEFAULT NULL,
  `password` varchar(225) DEFAULT NULL,
  `contactNo` varchar(225) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `qualification` varchar(225) DEFAULT NULL,
  `specialization` varchar(225) DEFAULT NULL,
  `exprience` varchar(225) DEFAULT NULL,
  `userId` bigint DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `doctor` */

insert  into `doctor`(`id`,`firstName`,`lastName`,`userName`,`password`,`contactNo`,`dob`,`email`,`qualification`,`specialization`,`exprience`,`userId`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,'Cleo','Maldonado','Popyd123','Pa$$w0rd!','9685456585','1997-10-10','wusy@mailinator.com','Aut deserunt sint de',NULL,'2 Year',2,'Admin123','Admin123','2021-11-10 08:09:57','2021-11-10 08:09:57');

/*Table structure for table `insurance` */

DROP TABLE IF EXISTS `insurance`;

CREATE TABLE `insurance` (
  `Id` bigint NOT NULL,
  `patientId` bigint DEFAULT NULL,
  `patientName` varchar(225) DEFAULT NULL,
  `name` varchar(225) DEFAULT NULL,
  `companyName` varchar(225) DEFAULT NULL,
  `insuranceAmount` varchar(225) DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `insurance` */

insert  into `insurance`(`Id`,`patientId`,`patientName`,`name`,`companyName`,`insuranceAmount`,`endDate`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,1,'Rajah Franks','Ariana Holmes','Humphrey and Garrison Associates','2500','2025-11-25','sipuniq','sipuniq','2021-11-24 11:34:53','2021-11-24 11:34:53');

/*Table structure for table `medicine` */

DROP TABLE IF EXISTS `medicine`;

CREATE TABLE `medicine` (
  `ID` bigint NOT NULL,
  `Name` varchar(225) DEFAULT NULL,
  `CompanyName` varchar(225) DEFAULT NULL,
  `Price` varchar(225) DEFAULT NULL,
  `Status` varchar(225) DEFAULT NULL,
  `Description` varchar(1500) DEFAULT NULL,
  `Created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `medicine` */

insert  into `medicine`(`ID`,`Name`,`CompanyName`,`Price`,`Status`,`Description`,`Created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,'Rafael Cortez','Caesar Todd','558','Available','Aliquam aspernatur n','Admin123','Admin123','2021-11-13 15:36:47','2021-11-13 15:36:47');

/*Table structure for table `patient` */

DROP TABLE IF EXISTS `patient`;

CREATE TABLE `patient` (
  `id` bigint NOT NULL,
  `firstName` varchar(225) DEFAULT NULL,
  `lastName` varchar(225) DEFAULT NULL,
  `userName` varchar(225) DEFAULT NULL,
  `password` varchar(225) DEFAULT NULL,
  `contactNo` varchar(225) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `city` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `userId` bigint DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `patient` */

insert  into `patient`(`id`,`firstName`,`lastName`,`userName`,`password`,`contactNo`,`dob`,`email`,`city`,`address`,`userId`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,'Rajah','Franks','sipuniq','Pa$$w0rd!','9685456585','1997-10-10','Hariomukati741@gmail.com','Proident cumque qua','Architecto voluptas',4,'root','root','2021-11-13 10:07:06','2021-11-13 10:07:18');

/*Table structure for table `prescription` */

DROP TABLE IF EXISTS `prescription`;

CREATE TABLE `prescription` (
  `Id` bigint NOT NULL,
  `patientId` bigint DEFAULT NULL,
  `patientName` varchar(225) DEFAULT NULL,
  `doctorId` bigint DEFAULT NULL,
  `doctorName` varchar(225) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `prescription` varchar(225) DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Fk_Patientid` (`patientId`),
  CONSTRAINT `Fk_Patientid` FOREIGN KEY (`patientId`) REFERENCES `patient` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `prescription` */

insert  into `prescription`(`Id`,`patientId`,`patientName`,`doctorId`,`doctorName`,`date`,`prescription`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,1,'Rajah Franks',1,'Cleo Maldonado','2021-11-13','zxc xc cx cxv','Popyd123','Popyd123','2021-11-13 11:53:13','2021-11-13 11:53:13');

/*Table structure for table `room` */

DROP TABLE IF EXISTS `room`;

CREATE TABLE `room` (
  `Id` bigint NOT NULL,
  `wardId` bigint DEFAULT NULL,
  `wardName` varchar(225) DEFAULT NULL,
  `roomNo` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Description` varchar(225) DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Fk_Ward_Id` (`wardId`),
  CONSTRAINT `Fk_Ward_Id` FOREIGN KEY (`wardId`) REFERENCES `ward` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `room` */

insert  into `room`(`Id`,`wardId`,`wardName`,`roomNo`,`Description`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,1,'Burke Woods','101','vyfuv','Admin123','Admin123','2021-11-12 13:05:40','2021-11-12 13:05:40');

/*Table structure for table `scheduledoctor` */

DROP TABLE IF EXISTS `scheduledoctor`;

CREATE TABLE `scheduledoctor` (
  `id` bigint NOT NULL,
  `doctorId` bigint DEFAULT NULL,
  `doctorName` varchar(225) DEFAULT NULL,
  `time` varchar(225) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `city` varchar(225) DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Doctor_Id` (`doctorId`),
  CONSTRAINT `FK_Doctor_Id` FOREIGN KEY (`doctorId`) REFERENCES `doctor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `scheduledoctor` */

insert  into `scheduledoctor`(`id`,`doctorId`,`doctorName`,`time`,`date`,`address`,`city`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,1,'Cleo Maldonado','vjv','2021-11-12','bj','vj','Popyd123','Popyd123','2021-11-12 16:15:03','2021-11-12 16:15:03');

/*Table structure for table `staff` */

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `Id` bigint NOT NULL,
  `firstName` varchar(225) DEFAULT NULL,
  `lastName` varchar(225) DEFAULT NULL,
  `userName` varchar(225) DEFAULT NULL,
  `password` varchar(225) DEFAULT NULL,
  `contactNo` varchar(225) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `qualification` varchar(225) DEFAULT NULL,
  `experience` varchar(225) DEFAULT NULL,
  `userId` bigint DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `staff` */

insert  into `staff`(`Id`,`firstName`,`lastName`,`userName`,`password`,`contactNo`,`dob`,`email`,`qualification`,`experience`,`userId`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,'Rosalyn','Alston','Hyteci123','Pa$$w0rd!','9685456585','1997-10-10','boziguxa@mailinator.com','Architecto est eos','2 Year',3,'Admin123','Admin123','2021-11-10 09:38:40','2021-11-10 09:38:40');

/*Table structure for table `stafftiming` */

DROP TABLE IF EXISTS `stafftiming`;

CREATE TABLE `stafftiming` (
  `Id` bigint NOT NULL,
  `staffId` bigint DEFAULT NULL,
  `StaffName` varchar(225) DEFAULT NULL,
  `Timing` varchar(225) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `wardName` varchar(225) DEFAULT NULL,
  `roomNo` varchar(225) DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `stafftiming` */

insert  into `stafftiming`(`Id`,`staffId`,`StaffName`,`Timing`,`date`,`wardName`,`roomNo`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,1,'Rosalyn Alston','11 AM','2021-11-14','jvju','101','Hyteci123','Hyteci123','2021-11-13 13:44:01','2021-11-14 08:05:37');

/*Table structure for table `testreport` */

DROP TABLE IF EXISTS `testreport`;

CREATE TABLE `testreport` (
  `Id` bigint NOT NULL,
  `patientId` bigint DEFAULT NULL,
  `PatientName` varchar(225) DEFAULT NULL,
  `doctorId` bigint DEFAULT NULL,
  `doctorName` varchar(225) DEFAULT NULL,
  `fileName` varchar(755) DEFAULT NULL,
  `Description` varchar(1500) DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Fk_patient_id` (`patientId`),
  CONSTRAINT `Fk_patient_id` FOREIGN KEY (`patientId`) REFERENCES `patient` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `testreport` */

insert  into `testreport`(`Id`,`patientId`,`PatientName`,`doctorId`,`doctorName`,`fileName`,`Description`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,1,'Rajah Franks',1,'Cleo Maldonado','nullalgoritham.txt','cfhfyf','sipuniq','sipuniq','2021-11-13 18:40:35','2021-11-13 18:40:35'),
(2,1,'Rajah Franks',1,'Cleo Maldonado','RajahFranksJavaAssignment-Springboot.pdf','fgdfgf','Hyteci123','Hyteci123','2021-11-24 11:51:08','2021-11-24 11:51:08'),
(3,1,'Rajah Franks',1,'Cleo Maldonado','RajahFranksTHESIS.pdf','xc xcb cvx vcb','Hyteci123','Hyteci123','2021-11-24 13:01:29','2021-11-24 13:01:29');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `Id` bigint NOT NULL,
  `firstName` varchar(225) DEFAULT NULL,
  `lastName` varchar(225) DEFAULT NULL,
  `userName` varchar(225) DEFAULT NULL,
  `password` varchar(225) DEFAULT NULL,
  `contactNo` varchar(225) DEFAULT NULL,
  `RoleId` bigint DEFAULT NULL,
  `RoleName` varchar(225) DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `user` */

insert  into `user`(`Id`,`firstName`,`lastName`,`userName`,`password`,`contactNo`,`RoleId`,`RoleName`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,'Admin','Admin','Admin123','Admin@123','9685456585',1,'Admin','root','root','2021-11-09 08:37:56','2021-11-09 08:37:56'),
(2,'Cleo','Maldonado','Popyd123','Pa$$w0rd!','9685456585',2,'Doctor',NULL,NULL,NULL,NULL),
(3,'Rosalyn','Alston','Hyteci123','Pa$$w0rd!','9685456585',3,'Staff','Admin123','Admin123','2021-11-10 09:38:40','2021-11-10 09:38:40'),
(4,'Rajah','Franks','sipuniq','Pt@123','9685456586',4,'Patient','root','root','2021-11-13 10:07:06','2021-11-13 10:07:18'),
(5,'Brett','Ross','biwof','Pa$$w0rd!','9685456585',2,'Doctor','Admin123','Admin123','2021-11-14 07:44:00','2021-11-14 07:44:54'),
(6,'Raphael','Dyer','savepema','Pa$$w0rd!','9685452536',3,'Staff','Admin123','Admin123','2021-11-14 07:50:16','2021-11-14 07:50:16');

/*Table structure for table `ward` */

DROP TABLE IF EXISTS `ward`;

CREATE TABLE `ward` (
  `id` bigint NOT NULL,
  `name` varchar(225) DEFAULT NULL,
  `description` varchar(225) DEFAULT NULL,
  `created_by` varchar(225) DEFAULT NULL,
  `modified_by` varchar(225) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT NULL,
  `modified_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `ward` */

insert  into `ward`(`id`,`name`,`description`,`created_by`,`modified_by`,`created_datetime`,`modified_datetime`) values 
(1,'Burke Woods','Architecto et volupt','Admin123','Admin123','2021-11-10 11:28:28','2021-11-10 11:28:28');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
