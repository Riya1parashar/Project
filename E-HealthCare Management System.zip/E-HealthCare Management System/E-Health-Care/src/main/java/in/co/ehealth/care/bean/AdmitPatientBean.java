package in.co.ehealth.care.bean;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdmitPatientBean extends BaseBean {
	
	private long patientId;
	private String patientName;
	private String doctorName;
	private String wardName;
	private String roomNo;
	private String bedNo;
	private long bedId;
	private Date admitDate;
	private String status;
	private String disease;
	

	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return null;
	}

}
