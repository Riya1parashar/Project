package in.co.ehealth.care.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BedBean extends BaseBean {

	private long roomId;
	private String roomNo;
	private String bedNo;
	private String description;
	
	@Override
	public String getKey() {
		return String.valueOf(id);
	}

	@Override
	public String getValue() {
		return bedNo;
	}

}
