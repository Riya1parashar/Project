package in.co.ehealth.care.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BillBean extends BaseBean{

	
	private long patientId;
	private String patientName;
	private String amount;
	private String status;
	private String description;
	
	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return null;
	}

}
