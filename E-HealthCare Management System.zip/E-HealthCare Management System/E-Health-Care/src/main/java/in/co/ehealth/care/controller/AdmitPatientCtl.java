package in.co.ehealth.care.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import in.co.ehealth.care.bean.BaseBean;
import in.co.ehealth.care.bean.AdmitPatientBean;
import in.co.ehealth.care.exception.ApplicationException;
import in.co.ehealth.care.exception.DuplicateRecordException;
import in.co.ehealth.care.model.AdmitPatientModel;
import in.co.ehealth.care.model.PatientModel;
import in.co.ehealth.care.model.RoomModel;
import in.co.ehealth.care.util.DataUtility;
import in.co.ehealth.care.util.DataValidator;
import in.co.ehealth.care.util.PropertyReader;
import in.co.ehealth.care.util.ServletUtility;

/**
 * Servlet implementation class AdmitPatientCtl
 */

@WebServlet(name = "AdmitPatientCtl", urlPatterns = { "/ctl/admitPatient" })
public class AdmitPatientCtl extends BaseCtl {
	private static final long serialVersionUID = 1L;

	private static Logger log = Logger.getLogger(AdmitPatientCtl.class);
	
	

	@Override
	protected void preload(HttpServletRequest request) {
		try {
			request.setAttribute("patientList", new PatientModel().list());
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
	}

	protected boolean validate(HttpServletRequest request) {

		log.debug("AssignFacultyCtl Method validate Started");

		boolean pass = true;

		if (DataValidator.isNull(request.getParameter("doctorName"))) {
			request.setAttribute("doctorName", PropertyReader.getValue("error.require", "Doctor Name"));
			pass = false;
		}
		
		if ("-----Select-----".equalsIgnoreCase(request.getParameter("patientId"))) {
			request.setAttribute("patientId", PropertyReader.getValue("error.require", "Patient Name"));
			pass = false;
		}
		
		if (DataValidator.isNull(request.getParameter("wardName"))) {
			request.setAttribute("wardName", PropertyReader.getValue("error.require", "Ward Name"));
			pass = false;
		}
		
		if (DataValidator.isNull(request.getParameter("roomNo"))) {
			request.setAttribute("roomNo", PropertyReader.getValue("error.require", "Room No"));
			pass = false;
		}
		
		if (DataValidator.isNull(request.getParameter("bedNo"))) {
			request.setAttribute("bedNo", PropertyReader.getValue("error.require", "Bed No"));
			pass = false;
		}
		
		if (DataValidator.isNull(request.getParameter("date"))) {
			request.setAttribute("date", PropertyReader.getValue("error.require", "Date"));
			pass = false;
		}
		
		if (DataValidator.isNull(request.getParameter("disease"))) {
			request.setAttribute("disease", PropertyReader.getValue("error.require", "Disease"));
			pass = false;
		}

		log.debug("AdmitPatientCtl Method validate Ended");

		return pass;
	}

	@Override
	protected BaseBean populateBean(HttpServletRequest request) {

		log.debug("AdmitPatientCtl Method populatebean Started");

		AdmitPatientBean bean = new AdmitPatientBean();
		bean.setId(DataUtility.getLong(request.getParameter("id")));
		bean.setPatientId(DataUtility.getLong(request.getParameter("patientId")));
		bean.setDoctorName(DataUtility.getString(request.getParameter("doctorName")));
		bean.setWardName(DataUtility.getString(request.getParameter("wardName")));
		bean.setRoomNo(DataUtility.getString(request.getParameter("roomNo")));
		bean.setBedNo(DataUtility.getString(request.getParameter("bedNo")));
		bean.setAdmitDate(DataUtility.getDate(request.getParameter("date")));
		bean.setDisease(DataUtility.getString(request.getParameter("disease")));
		populateDTO(bean, request);

		log.debug("AdmitPatientCtl Method populatebean Ended");

		return bean;
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		log.debug("StudentCtl Method doGet Started");

		String op = DataUtility.getString(request.getParameter("operation"));

		AdmitPatientModel model = new AdmitPatientModel();

		long id = DataUtility.getLong(request.getParameter("id"));

		if (id > 0 || op != null) {

			AdmitPatientBean bean;
			try {
				bean = model.findByPK(id);

				ServletUtility.setBean(bean, request);

			} catch (ApplicationException e) {
				log.error(e);
				ServletUtility.handleException(e, request, response);
				return;
			}
		}
		ServletUtility.forward(getView(), request, response);
		log.debug("StudentCtl Method doGet Ended");

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		log.debug("AdmitPatientCtl Method doPost Started");
		String op = DataUtility.getString(request.getParameter("operation")); 
		AdmitPatientModel model = new AdmitPatientModel();
		long id = DataUtility.getLong(request.getParameter("id"));
		if (OP_SAVE.equalsIgnoreCase(op)) {
			AdmitPatientBean bean = (AdmitPatientBean) populateBean(request);
			bean.setStatus("Admited");
			try {
				if (id > 0) {
					model.update(bean);
					ServletUtility.setSuccessMessage("Data is successfully Updated", request);
				} else {
					long pk = model.add(bean);
					ServletUtility.setSuccessMessage("Data is successfully saved", request);
				}
			} catch (ApplicationException e) {
				log.error(e);
				ServletUtility.handleException(e, request, response);
				return;
			} catch (DuplicateRecordException e) {
				ServletUtility.setBean(bean, request);
				ServletUtility.setErrorMessage(e.getMessage(), request);
			}
			ServletUtility.forward(getView(), request, response);
		} else if (OP_DELETE.equalsIgnoreCase(op)) {
			AdmitPatientBean bean = (AdmitPatientBean) populateBean(request);
			try {
				model.delete(bean);
				ServletUtility.redirect(EHCView.ADMIT_PATIENT_LIST_CTL, request, response);
				return;
			} catch (ApplicationException e) {
				log.error(e);
				ServletUtility.handleException(e, request, response);
				return;
			}
		} else if (OP_CANCEL.equalsIgnoreCase(op)) {
			ServletUtility.redirect(EHCView.ADMIT_PATIENT_LIST_CTL, request, response);
		} else if (OP_RESET.equalsIgnoreCase(op)) {
			ServletUtility.redirect(EHCView.ADMIT_PATIENT_CTL, request, response);
			return;
		}
		ServletUtility.forward(getView(), request, response);
		log.debug("AdmitPatientCtl Method doPostEnded");
	}

	@Override
	protected String getView() {
		return EHCView.ADMIT_PATIENT_VIEW;
	}

}
