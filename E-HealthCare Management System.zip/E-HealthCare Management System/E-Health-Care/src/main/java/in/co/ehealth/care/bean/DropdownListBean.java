package in.co.ehealth.care.bean;

/**
 * DropdownListBean Interface has Abstract Method 
 */

public interface DropdownListBean
{
	public String getKey();

	public String getValue();
}
