package in.co.ehealth.care.bean;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class WardBean extends BaseBean {
	
	private String name;
	private String description;
	
	@Override
	public String getKey() {
		return String.valueOf(id);
	}

	@Override
	public String getValue() {
		return name;
	}

}
