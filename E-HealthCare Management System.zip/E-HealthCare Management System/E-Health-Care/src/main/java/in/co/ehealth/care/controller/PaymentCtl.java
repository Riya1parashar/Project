package in.co.ehealth.care.controller;

import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import in.co.ehealth.care.bean.BillBean;
import in.co.ehealth.care.exception.ApplicationException;
import in.co.ehealth.care.exception.DuplicateRecordException;
import in.co.ehealth.care.model.BillModel;
import in.co.ehealth.care.util.DataUtility;
import in.co.ehealth.care.util.ServletUtility;

/**
 * Servlet implementation class PaymentCtl
 */

@WebServlet(name = "PaymentCtl", urlPatterns = { "/ctl/payment" })
public class PaymentCtl extends BaseCtl {

	private static final long serialVersionUID = 1L;

	private static Logger log = Logger.getLogger(PaymentCtl.class.getName());

	/**
	 * Contains display logic
	 */
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		log.info("PaymentCtl doGet method start");

		HttpSession session = request.getSession();

		long bId = DataUtility.getLong(request.getParameter("bId"));
		if (bId > 0) {
			session.setAttribute("bId", bId);
		}
		ServletUtility.forward(getView(), request, response);
		log.info("PaymentCtl doGet method end");

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		log.info("PaymentCtl doGet method start");

		String op = DataUtility.getString(request.getParameter("operation"));

		HttpSession session = request.getSession();
		try {
			if ("Pay".equalsIgnoreCase(op)) {

				long bId = DataUtility.getLong(String.valueOf(session.getAttribute("bId")));

			   BillBean bean=new BillModel().findByPK(bId);
			   bean.setStatus("Paid");
			   session.setAttribute("bill", bean);
			   new BillModel().update(bean);
			   ServletUtility.setSuccessMessage("Bill Paid Successfully", request);
			   ServletUtility.forward(EHCView.SUCCESS_VIEW, request, response);
			}

		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DuplicateRecordException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ServletUtility.forward(getView(), request, response);
		log.info("PaymentCtl doGet method end");
	}

	@Override
	protected String getView() {
		return EHCView.PAYMENT_VIEW;
	}

}
